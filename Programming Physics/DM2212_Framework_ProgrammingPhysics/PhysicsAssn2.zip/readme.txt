A|D - Flippers
N - Nudge
Space - Launch ball
Esc - Exit Game