#include "Enemy.h"


Enemy::Enemy(int health, enemyType eT)
	:m_health(health), m_eT(eT)
{

}


Enemy::~Enemy()
{

}
